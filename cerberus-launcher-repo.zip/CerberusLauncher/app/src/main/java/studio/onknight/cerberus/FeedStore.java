package studio.onknight.cerberus;

import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** The user's subscribed RSS feeds, saved in the launcher's preferences. */
class FeedStore {

    static class Feed {
        String name, url;
        Feed(String name, String url) {
            this.name = name;
            this.url = url;
        }
    }

    private static final String KEY = "feeds";
    private static final String KEY_FILTER = "feed_filter";

    private final SharedPreferences prefs;

    FeedStore(SharedPreferences prefs) { this.prefs = prefs; }

    /** Starting set. Anyone can remove, rename or add to these in the app. */
    static List<Feed> defaults() {
        List<Feed> l = new ArrayList<>();
        l.add(new Feed("CBC Toronto", "https://www.cbc.ca/webfeed/rss/rss-canada-toronto"));
        l.add(new Feed("CBC Technology", "https://www.cbc.ca/webfeed/rss/rss-technology"));
        l.add(new Feed("CBC Sports", "https://www.cbc.ca/webfeed/rss/rss-sports"));
        l.add(new Feed("Sportsnet", "https://www.sportsnet.ca/feed/"));
        l.add(new Feed("CBS Sports NFL", "https://www.cbssports.com/rss/headlines/nfl/"));
        l.add(new Feed("MobileSyrup", "https://mobilesyrup.com/feed/"));
        l.add(new Feed("TWiT News", "https://feeds.twit.tv/latestposts.xml"));
        return l;
    }

    List<Feed> load() {
        List<Feed> out = new ArrayList<>();
        String s = prefs.getString(KEY, null);
        if (s == null) return defaults();
        try {
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Feed(o.getString("n"), o.getString("u")));
            }
        } catch (Exception e) {
            return defaults();
        }
        return out;
    }

    void save(List<Feed> feeds) {
        JSONArray a = new JSONArray();
        try {
            for (Feed f : feeds) a.put(new JSONObject().put("n", f.name).put("u", f.url));
        } catch (Exception ignored) { }
        prefs.edit().putString(KEY, a.toString()).apply();
    }

    /** Name of the one source being shown, or "" for all of them. */
    String filter() { return prefs.getString(KEY_FILTER, ""); }

    void setFilter(String name) { prefs.edit().putString(KEY_FILTER, name).apply(); }

    /** Adds https:// when missing and upgrades http to https (plain http is blocked on newer Android). */
    static String cleanUrl(String u) {
        u = u == null ? "" : u.trim();
        if (u.startsWith("feed://")) u = "https://" + u.substring(7);
        if (u.startsWith("http://")) u = "https://" + u.substring(7);
        if (!u.isEmpty() && !u.startsWith("https://")) u = "https://" + u;
        return u;
    }
}
