package studio.onknight.cerberus;

import android.text.Html;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns an ordinary website address into its RSS/Atom feed address.
 * Order: the address itself (maybe it is already a feed), the feed links the page advertises,
 * then the usual spots such as /feed and /rss. Call off the main thread.
 */
class FeedFinder {

    static class Found {
        String url, name;
    }

    private static final Pattern LINK_TAG = Pattern.compile("<link\\b[^>]*>", Pattern.CASE_INSENSITIVE);
    private static final Pattern TITLE = Pattern.compile("<title[^>]*>(.*?)</title>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern SITE_NAME = Pattern.compile(
            "<meta[^>]+property\\s*=\\s*[\"']og:site_name[\"'][^>]+content\\s*=\\s*[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);
    private static final String[] GUESSES = {"/feed", "/feed/", "/rss", "/rss/", "/rss.xml", "/feed.xml", "/atom.xml", "/index.xml"};

    /** Returns the feed for pageUrl, or throws with a message that is fine to show the user. */
    static Found find(String pageUrl) throws Exception {
        // 1. maybe it already is a feed
        try {
            RssParser.fetch(pageUrl, "x");
            Found f = new Found();
            f.url = pageUrl;
            return f;
        } catch (Exception ignored) { }

        // 2. what the page advertises
        String html = null;
        String base = pageUrl;
        String siteName = null;
        try {
            Page p = download(pageUrl);
            html = p.body;
            base = p.finalUrl;
            siteName = siteName(html);
        } catch (Exception e) {
            throw new Exception("Couldn't reach that address");
        }
        for (String cand : advertised(html, base)) {
            if (works(cand)) return found(cand, siteName);
        }

        // 3. the usual places, on the page's own folder and then the site root
        List<String> guesses = new ArrayList<>();
        URL u = new URL(base);
        String origin = u.getProtocol() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "");
        String path = u.getPath() == null ? "" : u.getPath();
        if (path.endsWith("/")) path = path.substring(0, path.length() - 1);
        if (!path.isEmpty()) {
            guesses.add(origin + path + "/feed");
            guesses.add(origin + path + "/rss");
        }
        for (String g : GUESSES) guesses.add(origin + g);
        for (String cand : guesses) {
            if (works(cand)) return found(cand, siteName);
        }
        throw new Exception("Couldn't find a feed on that site. It may not offer one any more.");
    }

    private static Found found(String url, String name) {
        Found f = new Found();
        f.url = url;
        f.name = name;
        return f;
    }

    private static boolean works(String url) {
        try {
            RssParser.fetch(url, "x");
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Feed addresses named in <link rel="alternate" type="application/rss+xml" href="..."> tags. */
    static List<String> advertised(String html, String base) {
        List<String> out = new ArrayList<>();
        if (html == null) return out;
        Matcher m = LINK_TAG.matcher(html);
        while (m.find()) {
            String tag = m.group();
            String type = attr(tag, "type");
            String rel = attr(tag, "rel");
            if (type == null || rel == null) continue;
            String t = type.toLowerCase();
            if (!rel.toLowerCase().contains("alternate")) continue;
            if (!(t.contains("rss") || t.contains("atom"))) continue;
            String href = attr(tag, "href");
            if (href == null) continue;
            try {
                String abs = new URL(new URL(base), Html.fromHtml(href, 0).toString().trim()).toString();
                if (abs.startsWith("http://")) abs = "https://" + abs.substring(7);
                if (!out.contains(abs)) out.add(abs);
            } catch (Exception ignored) { }
        }
        return out;
    }

    private static String attr(String tag, String name) {
        Matcher m = Pattern.compile("\\b" + name + "\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", Pattern.CASE_INSENSITIVE).matcher(tag);
        if (!m.find()) return null;
        return m.group(1) != null ? m.group(1) : m.group(2);
    }

    private static String siteName(String html) {
        if (html == null) return null;
        Matcher m = SITE_NAME.matcher(html);
        String n = null;
        if (m.find()) n = m.group(1);
        else {
            m = TITLE.matcher(html);
            if (m.find()) n = m.group(1);
        }
        if (n == null) return null;
        n = Html.fromHtml(n, 0).toString().replaceAll("\\s+", " ").trim();
        // "MobileSyrup | Canada's tech news" -> "MobileSyrup"
        String[] parts = n.split("\\s+[|\\u2013\\u2014-]\\s+");
        if (parts.length > 0 && !parts[0].trim().isEmpty()) n = parts[0].trim();
        if (n.length() > 40) n = n.substring(0, 40).trim();
        return n.isEmpty() ? null : n;
    }

    private static class Page {
        String body, finalUrl;
    }

    private static Page download(String url) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(12000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) CerberusLauncher/0.3");
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*");
            if (c.getResponseCode() / 100 != 2) throw new Exception("error " + c.getResponseCode());
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0 && bo.size() < 400 * 1024) bo.write(buf, 0, n); // the <head> is all we need
            Page p = new Page();
            p.body = bo.toString("UTF-8");
            p.finalUrl = c.getURL().toString();
            return p;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
