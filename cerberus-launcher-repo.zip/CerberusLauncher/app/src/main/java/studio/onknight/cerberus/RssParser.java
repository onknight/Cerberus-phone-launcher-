package studio.onknight.cerberus;

import android.text.Html;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Downloads and reads RSS 2.0 and Atom feeds. No libraries: just the XML parser built into Android. */
class RssParser {

    static class Article {
        String title, link, summary, source, image;
        long time; // millis, 0 if unknown
    }

    private static final int MAX_PER_FEED = 25;

    /** Fetches one feed. Throws if it can't be read or has no articles. Call off the main thread. */
    static List<Article> fetch(String feedUrl, String sourceName) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(feedUrl).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(12000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) CerberusLauncher/0.3");
            c.setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, */*");
            int code = c.getResponseCode();
            if (code / 100 != 2) throw new Exception("The site answered with error " + code);
            InputStream in = c.getInputStream();
            List<Article> list = parse(in, sourceName);
            in.close();
            if (list.isEmpty()) throw new Exception("No articles found in that feed");
            return list;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static List<Article> parse(InputStream in, String source) throws Exception {
        XmlPullParser p = Xml.newPullParser();
        p.setInput(in, null);
        List<Article> out = new ArrayList<>();
        Article a = null;
        boolean sawFeed = false;
        int ev = p.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT && out.size() < MAX_PER_FEED) {
            if (ev == XmlPullParser.START_TAG) {
                String n = p.getName();
                if (n.equals("rss") || n.equals("feed") || n.equals("rdf:RDF")) sawFeed = true;
                if (n.equals("item") || n.equals("entry")) {
                    a = new Article();
                    a.source = source;
                } else if (a != null) {
                    if (n.equals("media:content") || n.equals("media:thumbnail") || n.equals("enclosure")) {
                        String u = p.getAttributeValue(null, "url");
                        String type = p.getAttributeValue(null, "type");
                        String medium = p.getAttributeValue(null, "medium");
                        boolean isImg = n.equals("media:thumbnail")
                                || (type != null && type.startsWith("image"))
                                || "image".equals(medium)
                                || (type == null && medium == null && looksLikeImage(u));
                        if (isImg && a.image == null) a.image = goodImage(u);
                    } else if (n.equals("title") && a.title == null) a.title = clean(text(p));
                    else if (n.equals("link")) {
                        String href = p.getAttributeValue(null, "href");
                        String rel = p.getAttributeValue(null, "rel");
                        if (href != null) {
                            if (a.link == null || rel == null || rel.equals("alternate")) a.link = href;
                            text(p);
                        } else {
                            String t = text(p).trim();
                            if (!t.isEmpty()) a.link = t;
                        }
                    } else if (n.equals("description") || n.equals("summary")) {
                        if (a.summary == null) {
                            String raw = text(p);
                            if (a.image == null) a.image = firstImg(raw);
                            a.summary = clean(raw);
                        }
                    } else if (n.equals("content:encoded") || n.equals("content")) {
                        {
                            String raw = text(p);
                            if (a.image == null) a.image = firstImg(raw);
                            if (a.summary == null || a.summary.isEmpty()) a.summary = clean(raw);
                        }
                    } else if (n.equals("pubDate") || n.equals("published") || n.equals("updated") || n.equals("dc:date")) {
                        long t = parseDate(text(p).trim());
                        if (t > 0 && (a.time == 0 || n.equals("pubDate") || n.equals("published"))) a.time = t;
                    }
                }
            } else if (ev == XmlPullParser.END_TAG) {
                String n = p.getName();
                if ((n.equals("item") || n.equals("entry")) && a != null) {
                    if (a.title != null && !a.title.isEmpty() && a.link != null) {
                        if (a.summary != null && a.summary.length() > 220) {
                            a.summary = a.summary.substring(0, 220).trim() + "…";
                        }
                        out.add(a);
                    }
                    a = null;
                }
            }
            ev = p.next();
        }
        if (!sawFeed) throw new Exception("That address isn't an RSS or Atom feed");
        return out;
    }

    private static final java.util.regex.Pattern IMG =
            java.util.regex.Pattern.compile("<img[^>]+src\\s*=\\s*[\"']([^\"']+)[\"']", java.util.regex.Pattern.CASE_INSENSITIVE);

    private static String firstImg(String html) {
        if (html == null) return null;
        java.util.regex.Matcher m = IMG.matcher(html);
        while (m.find()) {
            String u = goodImage(android.text.Html.fromHtml(m.group(1), 0).toString());
            if (u != null) return u;
        }
        return null;
    }

    private static boolean looksLikeImage(String u) {
        if (u == null) return false;
        String l = u.toLowerCase(Locale.US);
        int q = l.indexOf('?');
        if (q > 0) l = l.substring(0, q);
        return l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png") || l.endsWith(".webp");
    }

    /** Returns an https image address, or null for tracking pixels, icons and relative links. */
    private static String goodImage(String u) {
        if (u == null) return null;
        u = u.trim();
        if (u.startsWith("//")) u = "https:" + u;
        if (u.startsWith("http://")) u = "https://" + u.substring(7);
        if (!u.startsWith("https://")) return null;
        String l = u.toLowerCase(Locale.US);
        if (l.contains("1x1") || l.contains("pixel") || l.contains("spacer") || l.contains("/emoji") || l.endsWith(".gif")) return null;
        return u;
    }

    /** Text of the current element, including CDATA; leaves the parser on the matching end tag. */
    private static String text(XmlPullParser p) throws Exception {
        StringBuilder sb = new StringBuilder();
        int depth = 1;
        while (depth > 0) {
            int e = p.next();
            if (e == XmlPullParser.TEXT) sb.append(p.getText());
            else if (e == XmlPullParser.START_TAG) depth++;
            else if (e == XmlPullParser.END_TAG) depth--;
            else if (e == XmlPullParser.END_DOCUMENT) break;
        }
        return sb.toString();
    }

    private static String clean(String s) {
        if (s == null) return "";
        String t = Html.fromHtml(s, Html.FROM_HTML_MODE_COMPACT).toString();
        return t.replace('￼', ' ').replaceAll("\\s+", " ").trim();
    }

    private static final String[] DATE_FORMATS = {
            "EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, d MMM yyyy HH:mm:ss Z",
            "EEE, d MMM yyyy HH:mm:ss zzz", "dd MMM yyyy HH:mm:ss Z",
            "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'"
    };

    static long parseDate(String s) {
        if (s == null || s.isEmpty()) return 0;
        for (String f : DATE_FORMATS) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(f, Locale.US);
                if (f.endsWith("'Z'")) sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
                return sdf.parse(s).getTime();
            } catch (Exception ignored) { }
        }
        return 0;
    }

    /** "5 min ago", "3 h ago", "2 d ago", or a short date. */
    static String ago(long t) {
        if (t <= 0) return "";
        long diff = System.currentTimeMillis() - t;
        if (diff < 0) diff = 0;
        long min = diff / 60000;
        if (min < 1) return "just now";
        if (min < 60) return min + " min ago";
        if (min < 60 * 24) return (min / 60) + " h ago";
        if (min < 60 * 24 * 7) return (min / (60 * 24)) + " d ago";
        return new SimpleDateFormat("MMM d", Locale.getDefault()).format(new java.util.Date(t));
    }
}
