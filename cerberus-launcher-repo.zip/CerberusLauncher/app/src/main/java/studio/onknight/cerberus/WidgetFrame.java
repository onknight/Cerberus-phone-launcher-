package studio.onknight.cerberus;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/**
 * Wraps one block on the home screen (built-in clock/weather or a hosted Android widget).
 * Long-press enters edit mode: drag to move, bottom-right handle to resize, top-right X to remove.
 * Tap outside (handled by MainActivity) leaves edit mode.
 */
class WidgetFrame extends FrameLayout {

    interface Listener {
        void onEditStart(WidgetFrame f);
        void onChanged(WidgetFrame f);
        void onRemove(WidgetFrame f);
        /** The block is being held against the left (-1) or right (+1) screen edge while dragging. */
        void onEdgeHold(WidgetFrame f, int dir);
    }

    static final int MODE_NONE = 0, MODE_DRAG = 1, MODE_RESIZE = 2, MODE_CLOSE = 3;

    final String kind;      // "clock", "weather" or "widget"
    final int widgetId;     // Android appWidgetId for "widget", else -1

    /** Which home page this block lives on, and the width of one page in px. */
    int page;
    int pageWidthPx;

    private int edgeDir;    // -1, 0 or +1 while dragging near a screen edge
    private final Runnable edgeHold = new Runnable() {
        @Override public void run() {
            if (mode != MODE_DRAG || edgeDir == 0) return;
            listener.onEdgeHold(WidgetFrame.this, edgeDir);
            // still held at the edge: flip again after a pause
            if (edgeDir != 0) postDelayed(this, 900);
        }
    };

    private final Listener listener;
    private final float d;
    private final int slop;
    private final EditChrome chrome;
    private boolean editing;
    private int mode = MODE_NONE;
    private float downX, downY;
    private int startL, startT, startW, startH;

    private final Runnable longPress = new Runnable() {
        @Override public void run() { beginEdit(); }
    };

    WidgetFrame(Context c, String kind, int widgetId, Listener l) {
        super(c);
        this.kind = kind;
        this.widgetId = widgetId;
        this.listener = l;
        this.d = c.getResources().getDisplayMetrics().density;
        this.slop = ViewConfiguration.get(c).getScaledTouchSlop();
        setClickable(true); // so this frame always receives the whole gesture
        chrome = new EditChrome(c);
        chrome.setVisibility(GONE);
        addView(chrome, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    void setContent(View v) {
        addView(v, 0, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    View getContent() {
        return getChildCount() > 1 ? getChildAt(0) : null;
    }

    boolean isEditing() { return editing; }

    void setEditing(boolean on) {
        editing = on;
        mode = MODE_NONE;
        stopEdge();
        chrome.setVisibility(on ? VISIBLE : GONE);
    }

    /** Enter edit mode without a gesture in progress (used right after adding a block). */
    void startEditing() {
        setEditing(true);
        listener.onEditStart(this);
    }

    @Override public boolean dispatchTouchEvent(MotionEvent e) {
        if (editing) {
            editTouch(e);
            return true;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX();
                downY = e.getRawY();
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
                break;
            case MotionEvent.ACTION_MOVE:
                if (Math.abs(e.getRawX() - downX) > slop || Math.abs(e.getRawY() - downY) > slop)
                    removeCallbacks(longPress);
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(longPress);
                break;
            default:
                break;
        }
        return super.dispatchTouchEvent(e);
    }

    private void beginEdit() {
        if (editing) return;
        // Tell the hosted widget its touch was cancelled, then take over the gesture.
        long now = SystemClock.uptimeMillis();
        MotionEvent cancel = MotionEvent.obtain(now, now, MotionEvent.ACTION_CANCEL, 0f, 0f, 0);
        super.dispatchTouchEvent(cancel);
        cancel.recycle();
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
        setEditing(true);
        mode = MODE_DRAG;
        captureStart();
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        listener.onEditStart(this);
    }

    private void captureStart() {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
        startL = lp.leftMargin;
        startT = lp.topMargin;
        startW = lp.width;
        startH = lp.height;
    }

    private void editTouch(MotionEvent e) {
        float rx = e.getRawX(), ry = e.getRawY();
        float hs = 44 * d;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = rx;
                downY = ry;
                captureStart();
                if (e.getX() > getWidth() - hs && e.getY() < hs) mode = MODE_CLOSE;
                else if (e.getX() > getWidth() - hs && e.getY() > getHeight() - hs) mode = MODE_RESIZE;
                else mode = MODE_DRAG;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                break;
            case MotionEvent.ACTION_MOVE: {
                int dx = (int) (rx - downX), dy = (int) (ry - downY);
                if (mode == MODE_DRAG) {
                    move(startL + dx, startT + dy);
                    checkEdge(rx);
                } else if (mode == MODE_RESIZE) resize(startW + dx, startH + dy);
                break;
            }
            case MotionEvent.ACTION_UP:
                stopEdge();
                if (mode == MODE_CLOSE) {
                    if (e.getX() > getWidth() - hs && e.getY() < hs) listener.onRemove(this);
                } else if (mode == MODE_DRAG || mode == MODE_RESIZE) {
                    listener.onChanged(this);
                }
                mode = MODE_NONE;
                break;
            case MotionEvent.ACTION_CANCEL:
                stopEdge();
                if (mode == MODE_DRAG || mode == MODE_RESIZE) listener.onChanged(this);
                mode = MODE_NONE;
                break;
            default:
                break;
        }
    }

    /** Watches for the finger resting at a screen edge so the block can go to the next page. */
    private void checkEdge(float rx) {
        float zone = 28 * d;
        int dir = rx < zone ? -1 : (pageWidthPx > 0 && rx > pageWidthPx - zone ? 1 : 0);
        if (dir == edgeDir) return;
        removeCallbacks(edgeHold);
        edgeDir = dir;
        if (dir != 0) postDelayed(edgeHold, 550);
    }

    private void stopEdge() {
        removeCallbacks(edgeHold);
        edgeDir = 0;
    }

    /** Called by MainActivity after it moved this block onto another page mid-drag. */
    void shiftStart(int dxPx) {
        startL += dxPx;
    }

    private int pageLeft() { return page * pageWidthPx; }

    private int pageRight(View parent) {
        return pageWidthPx > 0 ? pageLeft() + pageWidthPx : parent.getWidth();
    }

    private void move(int l, int t) {
        View p = (View) getParent();
        if (p == null) return;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
        lp.leftMargin = Math.max(pageLeft(), Math.min(l, pageRight(p) - lp.width));
        lp.topMargin = Math.max(0, Math.min(t, p.getHeight() - lp.height));
        setLayoutParams(lp);
    }

    private void resize(int w, int h) {
        View p = (View) getParent();
        if (p == null) return;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
        int min = (int) (80 * d);
        lp.width = Math.max(min, Math.min(w, pageRight(p) - lp.leftMargin));
        lp.height = Math.max(min, Math.min(h, p.getHeight() - lp.topMargin));
        setLayoutParams(lp);
    }

    /** Orange border, resize handle (bottom-right) and remove button (top-right). */
    private static class EditChrome extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final float d;

        EditChrome(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2 * d);
            p.setColor(0xFFFF6A1A);
            r.set(d, d, w - d, h - d);
            cv.drawRoundRect(r, 14 * d, 14 * d, p);

            float rad = 15 * d, m = 6 * d;
            // remove button
            float cx = w - m - rad, cy = m + rad;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFF6A1A);
            cv.drawCircle(cx, cy, rad, p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0xFF1A0A05);
            p.setStrokeWidth(2.5f * d);
            p.setStrokeCap(Paint.Cap.ROUND);
            float k = rad * 0.4f;
            cv.drawLine(cx - k, cy - k, cx + k, cy + k, p);
            cv.drawLine(cx - k, cy + k, cx + k, cy - k, p);

            // resize handle
            cx = w - m - rad;
            cy = h - m - rad;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFF6A1A);
            cv.drawCircle(cx, cy, rad, p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0xFF1A0A05);
            cv.drawLine(cx - k, cy + k, cx + k, cy - k, p);
            cv.drawLine(cx + k, cy - k, cx + k, cy - k * 0.1f, p);
            cv.drawLine(cx + k, cy - k, cx + k * 0.1f, cy - k, p);
            cv.drawLine(cx - k, cy + k, cx - k, cy + k * 0.1f, p);
            cv.drawLine(cx - k, cy + k, cx - k * 0.1f, cy + k, p);
        }
    }
}
