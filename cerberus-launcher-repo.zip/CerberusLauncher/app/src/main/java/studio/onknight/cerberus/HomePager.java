package studio.onknight.cerberus;

import android.content.Context;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

/**
 * Holds the wide home board and turns sideways swipes into page changes.
 * Taps, long-presses and widget touches pass through untouched; only a clearly
 * horizontal drag is taken over.
 */
class HomePager extends FrameLayout {

    interface Host {
        boolean canSwipePages();
        /** Finger has moved dx px sideways since the swipe started. */
        void onPageDrag(float dx);
        /** Finger lifted after moving dx px with velocity vx (px/s). */
        void onPageRelease(float dx, float vx);
    }

    private final Host host;
    private final int slop;
    private float downX, downY;
    private boolean swiping;
    private VelocityTracker vt;

    HomePager(Context c, Host host) {
        super(c);
        this.host = host;
        this.slop = ViewConfiguration.get(c).getScaledTouchSlop();
        setClipChildren(true);
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) {
        track(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                swiping = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (!swiping && host.canSwipePages()) {
                    float dx = e.getX() - downX, dy = e.getY() - downY;
                    if (Math.abs(dx) > slop * 1.5f && Math.abs(dx) > Math.abs(dy) * 1.3f) {
                        swiping = true;
                        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!swiping) recycle();
                break;
            default:
                break;
        }
        return swiping;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        track(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!swiping && host.canSwipePages()) {
                    float dx = e.getX() - downX, dy = e.getY() - downY;
                    if (Math.abs(dx) > slop * 1.5f && Math.abs(dx) > Math.abs(dy) * 1.3f) swiping = true;
                }
                if (swiping) host.onPageDrag(e.getX() - downX);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (swiping) {
                    float vx = 0;
                    if (vt != null) {
                        vt.computeCurrentVelocity(1000);
                        vx = vt.getXVelocity();
                    }
                    host.onPageRelease(e.getX() - downX, vx);
                }
                swiping = false;
                recycle();
                return true;
            }
            default:
                return true;
        }
    }

    private void track(MotionEvent e) {
        if (vt == null) vt = VelocityTracker.obtain();
        vt.addMovement(e);
    }

    private void recycle() {
        if (vt != null) {
            vt.recycle();
            vt = null;
        }
    }
}
