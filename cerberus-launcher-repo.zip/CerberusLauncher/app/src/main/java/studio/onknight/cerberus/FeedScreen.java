package studio.onknight.cerberus;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * The news screen that slides in from the left of home page 1.
 * Local RSS only: headlines, source, time and a short summary; tap opens the article in the browser.
 */
class FeedScreen extends FrameLayout {

    interface Listener {
        /** Finger moved dx px (negative = leftwards) while closing the feed. */
        void onCloseDrag(float dx);
        void onCloseRelease(float dx, float vx);
    }

    private static final int ORANGE = 0xFFFF8A3D;
    private static final long STALE_MS = 15 * 60 * 1000L;

    private final Listener listener;
    private final FeedStore store;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final float d;
    private final int slop;

    private final LinearLayout list;
    private final LinearLayout chips;
    private final TextView status;
    private final TextView refreshBtn;

    private List<RssParser.Article> articles = new ArrayList<>();
    private long lastLoad;
    private int generation;
    private boolean loading;

    // touch state for swipe-left-to-close
    private float downX, downY;
    private boolean closing;
    private VelocityTracker vt;

    FeedScreen(Context c, FeedStore store, Listener l) {
        super(c);
        this.store = store;
        this.listener = l;
        d = c.getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        setBackgroundColor(0xF2090A0F);
        setClickable(true);

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        addView(col, new LayoutParams(-1, -1));

        // header
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(px(20), px(12), px(12), px(4));
        LinearLayout titles = new LinearLayout(c);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView date = new TextView(c);
        date.setText(new java.text.SimpleDateFormat("EEEE, MMMM d", java.util.Locale.getDefault())
                .format(new java.util.Date()).toUpperCase(java.util.Locale.getDefault()));
        date.setTextColor(0x99FFFFFF);
        date.setTextSize(11);
        date.setLetterSpacing(0.08f);
        titles.addView(date);
        TextView title = new TextView(c);
        title.setText("News");
        title.setTextColor(Color.WHITE);
        title.setTextSize(32);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titles.addView(title);
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        refreshBtn = headerButton("Refresh");
        refreshBtn.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { refresh(); }
        });
        head.addView(refreshBtn);
        TextView manage = headerButton("Feeds");
        manage.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { manageFeeds(); }
        });
        head.addView(manage);
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // source chips
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        chips = new LinearLayout(c);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(px(16), px(4), px(16), px(8));
        hs.addView(chips, new LayoutParams(-2, -2));
        col.addView(hs, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(c);
        status.setTextColor(0xAAFFFFFF);
        status.setTextSize(13);
        status.setPadding(px(20), px(2), px(20), px(6));
        status.setVisibility(GONE);
        col.addView(status, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(px(12), 0, px(12), px(24));
        sv.addView(list, new LayoutParams(-1, -2));
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        rebuildChips();
    }

    private int px(float dp) { return Math.round(dp * d); }

    private GradientDrawable rounded(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(r * d);
        return g;
    }

    private TextView headerButton(String t) {
        TextView b = new TextView(getContext());
        b.setText(t);
        b.setTextColor(ORANGE);
        b.setTextSize(14);
        b.setBackground(rounded(0x26FFFFFF, 18));
        b.setPadding(px(14), px(8), px(14), px(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = px(8);
        b.setLayoutParams(lp);
        return b;
    }

    /** Called when the feed is about to be shown. Reloads if nothing has been loaded lately. */
    void onShown() {
        if (articles.isEmpty() || System.currentTimeMillis() - lastLoad > STALE_MS) refresh();
        else render(); // update the "x min ago" labels
    }

    // =====================================================================================
    // Loading
    // =====================================================================================

    void refresh() {
        if (loading) return;
        final List<FeedStore.Feed> feeds = store.load();
        if (feeds.isEmpty()) {
            articles = new ArrayList<>();
            showStatus("No feeds yet. Tap Feeds to add one.");
            render();
            return;
        }
        loading = true;
        final int gen = ++generation;
        refreshBtn.setText("Loading…");
        showStatus(null);
        final List<RssParser.Article> all = Collections.synchronizedList(new ArrayList<RssParser.Article>());
        final List<String> failed = Collections.synchronizedList(new ArrayList<String>());
        final AtomicInteger left = new AtomicInteger(feeds.size());
        for (final FeedStore.Feed f : feeds) {
            pool.execute(new Runnable() { @Override public void run() {
                try {
                    all.addAll(RssParser.fetch(f.url, f.name));
                } catch (Throwable t) {
                    failed.add(f.name);
                }
                if (left.decrementAndGet() == 0) {
                    ui.post(new Runnable() { @Override public void run() { finish(gen, all, failed); } });
                }
            } });
        }
    }

    private void finish(int gen, List<RssParser.Article> all, List<String> failed) {
        loading = false;
        refreshBtn.setText("Refresh");
        if (gen != generation) return;
        List<RssParser.Article> sorted = new ArrayList<>(all);
        Collections.sort(sorted, new Comparator<RssParser.Article>() {
            @Override public int compare(RssParser.Article a, RssParser.Article b) { return Long.compare(b.time, a.time); }
        });
        if (!sorted.isEmpty()) {
            articles = sorted;
            lastLoad = System.currentTimeMillis();
        }
        if (sorted.isEmpty() && !failed.isEmpty()) {
            showStatus("Couldn't load the news. Check your connection and tap Refresh.");
        } else if (!failed.isEmpty()) {
            showStatus("Couldn't load: " + join(failed));
        } else {
            showStatus(null);
        }
        render();
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(l.get(i));
        }
        return sb.toString();
    }

    private void showStatus(String s) {
        if (s == null) status.setVisibility(GONE);
        else {
            status.setText(s);
            status.setVisibility(VISIBLE);
        }
    }

    // =====================================================================================
    // Drawing the list
    // =====================================================================================

    private void rebuildChips() {
        chips.removeAllViews();
        String sel = store.filter();
        List<FeedStore.Feed> feeds = store.load();
        boolean found = sel.isEmpty();
        for (FeedStore.Feed f : feeds) if (f.name.equals(sel)) found = true;
        if (!found) {
            sel = "";
            store.setFilter("");
        }
        addChip("All", "", sel.isEmpty());
        for (FeedStore.Feed f : feeds) addChip(f.name, f.name, f.name.equals(sel));
    }

    private void addChip(String label, final String value, boolean selected) {
        TextView t = new TextView(getContext());
        t.setText(label);
        t.setTextSize(14);
        t.setTextColor(selected ? Color.BLACK : Color.WHITE);
        t.setBackground(rounded(selected ? ORANGE : 0x33FFFFFF, 18));
        t.setPadding(px(14), px(7), px(14), px(7));
        t.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                store.setFilter(value);
                rebuildChips();
                render();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = px(8);
        chips.addView(t, lp);
    }

    private void render() {
        list.removeAllViews();
        String sel = store.filter();
        List<RssParser.Article> shown = new ArrayList<>();
        for (RssParser.Article a : articles) if (sel.isEmpty() || sel.equals(a.source)) shown.add(a);
        if (shown.isEmpty()) {
            if (status.getVisibility() != VISIBLE) {
                TextView t = new TextView(getContext());
                t.setText(loading ? "" : "Nothing to show yet.");
                t.setTextColor(0x99FFFFFF);
                t.setPadding(px(8), px(24), px(8), 0);
                list.addView(t);
            }
            return;
        }
        // Top story: the newest one that has a picture (or just the newest)
        RssParser.Article hero = shown.get(0);
        for (RssParser.Article a : shown) {
            if (a.image != null) { hero = a; break; }
        }
        list.addView(heroCard(hero));
        for (RssParser.Article a : shown) if (a != hero) list.addView(row(a));
    }

    private void roundClip(View v, final float radiusDp) {
        v.setClipToOutline(true);
        v.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View view, android.graphics.Outline o) {
                o.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusDp * d);
            }
        });
    }

    private String metaLine(RssParser.Article a) {
        String when = RssParser.ago(a.time);
        return a.source + (when.isEmpty() ? "" : "  \u00B7  " + when);
    }

    /** Big picture card with the headline over a dark fade, like a news app's lead story. */
    private View heroCard(final RssParser.Article a) {
        Context c = getContext();
        FrameLayout card = new FrameLayout(c);
        card.setBackground(rounded(0xFF2A1A12, 22));
        roundClip(card, 22);

        if (a.image != null) {
            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            card.addView(img, new LayoutParams(-1, -1));
            ImageLoader.load(a.image, img, getResources().getDisplayMetrics().widthPixels);
        }

        View fade = new View(c);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x00000000, 0x55000000, 0xEE000000});
        fade.setBackground(g);
        card.addView(fade, new LayoutParams(-1, -1));

        LinearLayout txt = new LinearLayout(c);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setPadding(px(18), px(18), px(18), px(18));
        TextView src = new TextView(c);
        src.setText(metaLine(a).toUpperCase(java.util.Locale.getDefault()));
        src.setTextColor(ORANGE);
        src.setTextSize(11);
        src.setLetterSpacing(0.08f);
        src.setTypeface(Typeface.DEFAULT_BOLD);
        txt.addView(src);
        TextView title = new TextView(c);
        title.setText(a.title);
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setLineSpacing(0, 1.05f);
        title.setMaxLines(4);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setShadowLayer(6, 0, 1, 0xAA000000);
        title.setPadding(0, px(6), 0, 0);
        txt.addView(title);
        card.addView(txt, new LayoutParams(-1, -2, Gravity.BOTTOM));

        card.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { open(a.link); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, px(a.image != null ? 250 : 170));
        lp.bottomMargin = px(14);
        card.setLayoutParams(lp);
        return card;
    }

    /** Headline and summary on the left, thumbnail on the right. */
    private View row(final RssParser.Article a) {
        Context c = getContext();
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackground(rounded(0x26FFFFFF, 18));
        row.setPadding(px(14), px(14), px(14), px(14));

        LinearLayout txt = new LinearLayout(c);
        txt.setOrientation(LinearLayout.VERTICAL);

        TextView meta = new TextView(c);
        meta.setText(metaLine(a));
        meta.setTextColor(ORANGE);
        meta.setTextSize(12);
        txt.addView(meta);

        TextView title = new TextView(c);
        title.setText(a.title);
        title.setTextColor(Color.WHITE);
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setMaxLines(3);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setPadding(0, px(4), 0, 0);
        txt.addView(title);

        if (a.summary != null && !a.summary.isEmpty() && !a.summary.equalsIgnoreCase(a.title)) {
            TextView sum = new TextView(c);
            sum.setText(a.summary);
            sum.setTextColor(0xA8FFFFFF);
            sum.setTextSize(13);
            sum.setMaxLines(2);
            sum.setEllipsize(android.text.TextUtils.TruncateAt.END);
            sum.setPadding(0, px(5), 0, 0);
            txt.addView(sum);
        }
        row.addView(txt, new LinearLayout.LayoutParams(0, -2, 1f));

        if (a.image != null) {
            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setBackground(rounded(0x33FFFFFF, 14));
            roundClip(img, 14);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(px(96), px(96));
            ip.leftMargin = px(12);
            ip.gravity = Gravity.CENTER_VERTICAL;
            row.addView(img, ip);
            ImageLoader.load(a.image, img, px(96) * 2);
        }

        row.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { open(a.link); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = px(10);
        row.setLayoutParams(lp);
        return row;
    }

    private void open(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception e) {
            toast("Couldn't open that link");
        }
    }

    private void toast(String s) { Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show(); }

    // =====================================================================================
    // Managing feeds
    // =====================================================================================

    void manageFeeds() {
        final List<FeedStore.Feed> feeds = store.load();
        String[] names = new String[feeds.size()];
        for (int i = 0; i < names.length; i++) names[i] = feeds.get(i).name;
        AlertDialog.Builder b = new AlertDialog.Builder(getContext()).setTitle("Your news feeds");
        if (names.length > 0) {
            b.setItems(names, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dlg, int which) { feedOptions(feeds.get(which)); }
            });
        } else {
            b.setMessage("No feeds yet.");
        }
        b.setPositiveButton("Add feed", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dlg, int which) { addFeed("", ""); }
        });
        b.setNeutralButton("Reset to defaults", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dlg, int which) {
                store.save(FeedStore.defaults());
                changed();
            }
        });
        b.setNegativeButton("Done", null);
        b.show();
    }

    private void feedOptions(final FeedStore.Feed f) {
        new AlertDialog.Builder(getContext()).setTitle(f.name)
                .setMessage(f.url)
                .setPositiveButton("Rename", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) { rename(f); }
                })
                .setNeutralButton("Remove", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) {
                        List<FeedStore.Feed> l = store.load();
                        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).url.equals(f.url)) l.remove(i);
                        store.save(l);
                        changed();
                        manageFeeds();
                    }
                })
                .setNegativeButton("Back", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) { manageFeeds(); }
                }).show();
    }

    private void rename(final FeedStore.Feed f) {
        final EditText in = new EditText(getContext());
        in.setSingleLine(true);
        in.setText(f.name);
        in.setSelection(f.name.length());
        new AlertDialog.Builder(getContext()).setTitle("Rename feed").setView(pad(in))
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) {
                        String n = in.getText().toString().trim();
                        if (!n.isEmpty()) {
                            List<FeedStore.Feed> l = store.load();
                            for (FeedStore.Feed x : l) if (x.url.equals(f.url)) x.name = n;
                            store.save(l);
                            changed();
                        }
                        manageFeeds();
                    }
                })
                .setNegativeButton("Cancel", null).show();
    }

    private View pad(View v) {
        FrameLayout w = new FrameLayout(getContext());
        w.setPadding(px(20), px(8), px(20), 0);
        w.addView(v, new LayoutParams(-1, -2));
        return w;
    }

    private void addFeed(String presetName, String presetUrl) {
        final EditText name = new EditText(getContext());
        name.setHint("Name (optional)");
        name.setSingleLine(true);
        name.setText(presetName);
        final EditText url = new EditText(getContext());
        url.setHint("Website or feed address");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setSingleLine(true);
        url.setText(presetUrl);
        LinearLayout box = new LinearLayout(getContext());
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(name, new LinearLayout.LayoutParams(-1, -2));
        box.addView(url, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(getContext()).setTitle("Add a feed").setView(pad(box))
                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) {
                        tryAdd(name.getText().toString().trim(), url.getText().toString());
                    }
                })
                .setNegativeButton("Cancel", null).show();
    }

    /** Accepts a feed address or a plain website address; finds the feed and checks it before saving. */
    private void tryAdd(final String nameIn, String urlIn) {
        final String u = FeedStore.cleanUrl(urlIn);
        if (u.length() < 12) {
            toast("Please enter a website or feed address");
            addFeed(nameIn, urlIn);
            return;
        }
        toast("Looking for the feed\u2026");
        pool.execute(new Runnable() { @Override public void run() {
            String err = null;
            FeedFinder.Found found = null;
            try {
                found = FeedFinder.find(u);
            } catch (Throwable t) {
                err = t.getMessage() == null ? "Couldn't reach that address" : t.getMessage();
            }
            final String e = err;
            final FeedFinder.Found fd = found;
            ui.post(new Runnable() { @Override public void run() {
                if (e != null || fd == null) {
                    new AlertDialog.Builder(getContext()).setTitle("Couldn't add that feed")
                            .setMessage((e == null ? "Couldn't find a feed" : e) + "\n\nTry the feed address itself if you know it.")
                            .setPositiveButton("OK", null).show();
                    return;
                }
                List<FeedStore.Feed> l = store.load();
                for (FeedStore.Feed f : l) {
                    if (f.url.equals(fd.url)) {
                        toast("That feed is already in your list");
                        return;
                    }
                }
                String name = !nameIn.isEmpty() ? nameIn : (fd.name != null ? fd.name : hostOf(fd.url));
                l.add(new FeedStore.Feed(name, fd.url));
                store.save(l);
                changed();
                toast("Added " + name);
            } });
        } });
    }

    private static String hostOf(String u) {
        try {
            String h = Uri.parse(u).getHost();
            if (h != null) return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception ignored) { }
        return u;
    }

    private void changed() {
        rebuildChips();
        articles = new ArrayList<>();
        lastLoad = 0;
        loading = false;
        refresh();
    }

    // =====================================================================================
    // Swipe left to close
    // =====================================================================================

    @Override public boolean onInterceptTouchEvent(MotionEvent e) {
        track(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                closing = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (!closing) {
                    float dx = e.getX() - downX, dy = e.getY() - downY;
                    if (dx < -slop * 1.5f && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                        closing = true;
                        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!closing) recycle();
                break;
            default:
                break;
        }
        return closing;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        track(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (closing) listener.onCloseDrag(Math.min(0, e.getX() - downX));
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (closing) {
                    float vx = 0;
                    if (vt != null) {
                        vt.computeCurrentVelocity(1000);
                        vx = vt.getXVelocity();
                    }
                    listener.onCloseRelease(Math.min(0, e.getX() - downX), vx);
                }
                closing = false;
                recycle();
                return true;
            default:
                return true;
        }
    }

    private void track(MotionEvent e) {
        if (vt == null) vt = VelocityTracker.obtain();
        vt.addMovement(e);
    }

    private void recycle() {
        if (vt != null) {
            vt.recycle();
            vt = null;
        }
    }
}
