package studio.onknight.cerberus;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Built-in weather block: current conditions, plus a 5-day forecast when the block is tall enough.
 * Location is detected from the IP address (ipapi.co) or set by city name (Open-Meteo geocoding).
 * Weather comes from Open-Meteo. No API keys.
 */
class WeatherPanel extends LinearLayout {

    private final SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final float d;
    private final WeatherIcon big;
    private final TextView temp, info;
    private final LinearLayout header, forecast;
    private final TextView[] dn = new TextView[5], dt = new TextView[5];
    private final WeatherIcon[] di = new WeatherIcon[5];
    private long lastFetch;

    WeatherPanel(Context c, SharedPreferences p) {
        super(c);
        prefs = p;
        d = c.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        int pad = (int) (12 * d);
        setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x80000000);
        bg.setCornerRadius(18 * d);
        setBackground(bg);

        header = new LinearLayout(c);
        header.setOrientation(HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        big = new WeatherIcon(c);
        header.addView(big, new LinearLayout.LayoutParams((int) (64 * d), (int) (64 * d)));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(VERTICAL);
        col.setPadding((int) (10 * d), 0, 0, 0);
        temp = text(c, Color.WHITE);
        temp.setText("--°");
        info = text(c, 0xFFE0C8B8);
        info.setText("Loading weather...");
        col.addView(temp);
        col.addView(info);
        header.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        addView(header, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        forecast = new LinearLayout(c);
        forecast.setOrientation(HORIZONTAL);
        forecast.setVisibility(GONE);
        for (int i = 0; i < 5; i++) {
            LinearLayout day = new LinearLayout(c);
            day.setOrientation(VERTICAL);
            day.setGravity(Gravity.CENTER_HORIZONTAL);
            dn[i] = text(c, 0xFFFFB27A);
            di[i] = new WeatherIcon(c);
            dt[i] = text(c, Color.WHITE);
            dn[i].setGravity(Gravity.CENTER);
            dt[i].setGravity(Gravity.CENTER);
            day.addView(dn[i], new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            day.addView(di[i], new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
            day.addView(dt[i], new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            forecast.addView(day, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        }
        addView(forecast, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.45f));
        applySizes((int) (300 * d), (int) (230 * d));
    }

    private TextView text(Context c, int color) {
        TextView t = new TextView(c);
        t.setTextColor(color);
        t.setSingleLine(true);
        t.setShadowLayer(6, 0, 1, 0xAA000000);
        return t;
    }

    @Override protected void onSizeChanged(final int w, final int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        post(new Runnable() { @Override public void run() { applySizes(w, h); } });
    }

    private void applySizes(int w, int h) {
        boolean sf = h >= 170 * d;
        forecast.setVisibility(sf ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams hp = (LinearLayout.LayoutParams) header.getLayoutParams();
        hp.weight = sf ? 0.55f : 1f;
        header.setLayoutParams(hp);
        float headerH = sf ? h * 0.55f : h;
        int is = (int) Math.max(24 * d, Math.min(headerH * 0.8f, w * 0.3f));
        LinearLayout.LayoutParams ip = (LinearLayout.LayoutParams) big.getLayoutParams();
        ip.width = is;
        ip.height = is;
        big.setLayoutParams(ip);
        float tsz = Math.max(18 * d, Math.min(headerH * 0.36f, w * 0.13f));
        temp.setTextSize(TypedValue.COMPLEX_UNIT_PX, tsz);
        info.setSingleLine(false);
        info.setMaxLines(3);
        info.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.max(tsz * 0.34f, 11 * d));
        float fs = Math.max(10 * d, Math.min(w / 5f * 0.2f, 14 * d));
        for (int i = 0; i < 5; i++) {
            dn[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, fs);
            dt[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, fs * 0.95f);
        }
    }

    // ---------- fetching ----------

    /** Fetch weather (throttled to every 15 minutes unless forced). */
    void refresh(boolean force) {
        long now = SystemClock.elapsedRealtime();
        if (!force && lastFetch != 0 && now - lastFetch < 15 * 60 * 1000L) return;
        lastFetch = now;
        if (!prefs.contains("lat")) {
            detectLocation(prefs, new Runnable() { @Override public void run() { fetch(); } },
                    new Runnable() { @Override public void run() {
                        info.setText("Weather unavailable.\nLong-press home > Set my city");
                    } });
        } else {
            fetch();
        }
    }

    private void fetch() {
        final double la = Double.parseDouble(prefs.getString("lat", "0"));
        final double lo = Double.parseDouble(prefs.getString("lon", "0"));
        final String cityName = prefs.getString("city", "");
        final boolean f = "F".equals(prefs.getString("unit", "F"));
        new Thread(new Runnable() { @Override public void run() {
            try {
                String u = "https://api.open-meteo.com/v1/forecast?latitude=" + la + "&longitude=" + lo
                        + "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m"
                        + "&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=5"
                        + (f ? "&temperature_unit=fahrenheit&wind_speed_unit=mph" : "");
                JSONObject j = new JSONObject(httpGet(u));
                JSONObject cur = j.getJSONObject("current");
                final int curCode = cur.getInt("weather_code");
                final String tempText = Math.round(cur.getDouble("temperature_2m")) + "°";
                final String infoText = cityName + " • " + wx(curCode) + "\nFeels " + Math.round(cur.getDouble("apparent_temperature"))
                        + "° • " + Math.round(cur.getDouble("relative_humidity_2m")) + "% • "
                        + Math.round(cur.getDouble("wind_speed_10m")) + (f ? " mph" : " km/h");
                JSONObject dl = j.getJSONObject("daily");
                JSONArray t = dl.getJSONArray("time"), hi = dl.getJSONArray("temperature_2m_max"),
                        lw = dl.getJSONArray("temperature_2m_min"), wc = dl.getJSONArray("weather_code");
                SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                SimpleDateFormat out = new SimpleDateFormat("EEE", Locale.getDefault());
                final int n = Math.min(5, t.length());
                final String[] names = new String[n], temps = new String[n];
                final int[] codes = new int[n];
                for (int i = 0; i < n; i++) {
                    names[i] = i == 0 ? "Today" : out.format(in.parse(t.getString(i)));
                    temps[i] = Math.round(hi.getDouble(i)) + "°/" + Math.round(lw.getDouble(i)) + "°";
                    codes[i] = wc.getInt(i);
                }
                ui.post(new Runnable() { @Override public void run() {
                    temp.setText(tempText);
                    info.setText(infoText);
                    big.setCode(curCode);
                    for (int k = 0; k < 5; k++) {
                        boolean has = k < n;
                        dn[k].setText(has ? names[k] : "");
                        dt[k].setText(has ? temps[k] : "");
                        di[k].setCode(has ? codes[k] : -1);
                    }
                } });
            } catch (Exception e) {
                ui.post(new Runnable() { @Override public void run() {
                    if (temp.getText().toString().startsWith("--")) info.setText(cityName + "\nWeather unavailable");
                } });
            }
        } }).start();
    }

    static String wx(int c) {
        if (c == 0) return "Clear";
        if (c <= 2) return "Partly cloudy";
        if (c == 3) return "Overcast";
        if (c == 45 || c == 48) return "Fog";
        if (c >= 51 && c <= 57) return "Drizzle";
        if (c >= 61 && c <= 67) return "Rain";
        if (c >= 71 && c <= 77) return "Snow";
        if (c >= 80 && c <= 82) return "Showers";
        if (c == 85 || c == 86) return "Snow showers";
        if (c >= 95) return "Thunderstorm";
        return "Cloudy";
    }

    // ---------- location (static so the menu works even if the weather block was removed) ----------

    static String httpGet(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "CerberusLauncher/0.1");
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String ln;
        while ((ln = r.readLine()) != null) sb.append(ln);
        r.close();
        c.disconnect();
        return sb.toString();
    }

    static boolean usesFahrenheit(String cc) {
        if (cc == null) return false;
        switch (cc.toUpperCase(Locale.US)) {
            case "US": case "LR": case "BS": case "BZ": case "KY": case "PW": case "FM": case "MH":
                return true;
            default:
                return false;
        }
    }

    static void saveLocation(SharedPreferences p, String city, double lat, double lon, String cc, boolean manual) {
        SharedPreferences.Editor e = p.edit()
                .putString("city", city)
                .putString("lat", String.valueOf(lat))
                .putString("lon", String.valueOf(lon))
                .putString("cc", cc)
                .putBoolean("loc_manual", manual);
        if (!p.contains("unit")) e.putString("unit", usesFahrenheit(cc) ? "F" : "C");
        e.apply();
    }

    /** Rough location from the IP address. Runs ok/fail on the main thread. */
    static void detectLocation(final SharedPreferences p, final Runnable ok, final Runnable fail) {
        final Handler h = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() { @Override public void run() {
            try {
                JSONObject j = new JSONObject(httpGet("https://ipapi.co/json/"));
                if (j.has("error") || !j.has("latitude")) throw new Exception("lookup failed");
                saveLocation(p, j.optString("city", "Home"), j.getDouble("latitude"), j.getDouble("longitude"),
                        j.optString("country_code", "US"), false);
                if (ok != null) h.post(ok);
            } catch (Exception e) {
                if (fail != null) h.post(fail);
            }
        } }).start();
    }

    /** Look a city up by name. Runs done on the main thread when the location was saved. */
    static void lookupCity(final Context ctx, final SharedPreferences p, final String name, final Runnable done) {
        if (name == null || name.isEmpty()) return;
        final Handler h = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() { @Override public void run() {
            try {
                String u = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&name=" + URLEncoder.encode(name, "UTF-8");
                JSONObject j = new JSONObject(httpGet(u));
                if (!j.has("results")) {
                    h.post(new Runnable() { @Override public void run() {
                        Toast.makeText(ctx, "No match for " + name, Toast.LENGTH_LONG).show(); } });
                    return;
                }
                JSONObject r = j.getJSONArray("results").getJSONObject(0);
                final String c = r.optString("name", name);
                saveLocation(p, c, r.getDouble("latitude"), r.getDouble("longitude"), r.optString("country_code", ""), true);
                h.post(new Runnable() { @Override public void run() {
                    Toast.makeText(ctx, "Location set to " + c, Toast.LENGTH_SHORT).show();
                    if (done != null) done.run();
                } });
            } catch (Exception e) {
                h.post(new Runnable() { @Override public void run() {
                    Toast.makeText(ctx, "Search failed. Check the internet connection.", Toast.LENGTH_LONG).show(); } });
            }
        } }).start();
    }
}
