package studio.onknight.cerberus;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Paint;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Cerberus Launcher 0.3.2 (beta) - phone home screen.
 * Swipeable home pages with widgets you can drag around (and drag to the next page),
 * a dock, and a swipe-up app drawer with search.
 * Hosts normal Android widgets (Symfonium etc.) plus built-in clock and weather blocks.
 */
public class MainActivity extends Activity implements WidgetFrame.Listener, HomePager.Host {

    private static final String PREFS = "cerberus";
    private static final int HOST_ID = 1024;
    private static final int REQ_BIND = 11, REQ_CONFIG = 12, REQ_WALLPAPER = 13, REQ_ROLE = 14;
    private static final int MAX_EDGE = 2400;
    private static final int DOCK_MAX = 20;
    private static final String VERSION = "0.3.2 beta";
    private static final int MAX_PAGES = 9;

    static class AppInfo {
        String label, lower, pkg, cls;
        Drawable icon;
    }

    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private float d;
    private int insetTop, insetBottom, imeBottom;

    private AppWidgetManager awm;
    private AppWidgetHost host;

    private FrameLayout root, board, drawer, pageBar;
    private HomePager pager;
    private PageDots pageDots;
    private ImageView wallpaper, wallpaperFill;

    // Home pages: one wide board, pageW px per page, slid sideways with translationX
    private int pageW, pageCount = 1, current = 0;
    private ValueAnimator pageAnim;
    private final Set<Integer> autoPages = new HashSet<>(); // pages made by dragging to the edge this edit
    private LinearLayout dock;          // the row of app icons (inside dockScroll)
    private LinearLayout dockBar;       // rounded bar: scrolling icons + the all-apps button pinned at the end
    private HorizontalScrollView dockScroll;
    private FeedScreen feed;
    private FeedStore feedStore;
    private boolean feedOpen, feedDragging;
    private EditText search;
    private GridView grid;
    private AppAdapter adapter;
    private WeatherPanel weatherPanel;
    private WidgetFrame editingFrame;
    private boolean drawerOpen;
    private GestureDetector gestures;

    private List<AppInfo> apps = new ArrayList<>();
    private final List<AppInfo> shown = new ArrayList<>();
    private final List<String> dockPkgs = new ArrayList<>();

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { refreshApps(); }
    };

    // =====================================================================================
    // Lifecycle
    // =====================================================================================

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        d = getResources().getDisplayMetrics().density;
        awm = AppWidgetManager.getInstance(this);
        host = new AppWidgetHost(this, HOST_ID);
        pageW = getResources().getDisplayMetrics().widthPixels;

        setupWindow();
        buildUi();
        loadWallpaper();
        loadLayout();
        loadDockPrefs();
        refreshApps();

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(pkgReceiver, f);

        gestures = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null || e2 == null || drawerOpen || feedOpen || editingFrame != null) return false;
                float dy = e1.getY() - e2.getY();
                float dx = Math.abs(e1.getX() - e2.getX());
                if (dy > 100 * d && dy > dx * 1.2f && vy < -800) {
                    openDrawer();
                    return true;
                }
                return false;
            }
        });

        if (!prefs.getBoolean("welcomed", false)) {
            ui.postDelayed(new Runnable() { @Override public void run() { showWelcome(); } }, 400);
        }
    }

    @Override protected void onStart() {
        super.onStart();
        try { host.startListening(); } catch (Exception ignored) { }
    }

    @Override protected void onStop() {
        super.onStop();
        try { host.stopListening(); } catch (Exception ignored) { }
    }

    @Override protected void onResume() {
        super.onResume();
        if (weatherPanel != null) weatherPanel.refresh(false);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(pkgReceiver); } catch (Exception ignored) { }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Home pressed while we are already showing
        if (Intent.ACTION_MAIN.equals(intent.getAction())) {
            closeDrawer(false);
            closeFeed(false);
            exitEdit();
            goToPage(0, true, null);
        }
    }

    @Override public void onBackPressed() {
        if (drawerOpen) closeDrawer(true);
        else if (feedOpen) closeFeed(true);
        else if (editingFrame != null) exitEdit();
        else if (current > 0) goToPage(0, true, null);
        // otherwise do nothing: we are the home screen
    }

    @Override public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN && editingFrame != null && !drawerOpen) {
            int[] loc = new int[2];
            editingFrame.getLocationOnScreen(loc);
            float x = ev.getRawX(), y = ev.getRawY();
            if (x < loc[0] || x > loc[0] + editingFrame.getWidth() || y < loc[1] || y > loc[1] + editingFrame.getHeight()) {
                exitEdit();
            }
        }
        if (!drawerOpen && !feedOpen && editingFrame == null) gestures.onTouchEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    // =====================================================================================
    // Window and UI
    // =====================================================================================

    private int px(float dp) { return Math.round(dp * d); }

    private float dpWidth() { return pageW / d; }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusDp * d);
        return g;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void setupWindow() {
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) w.setNavigationBarContrastEnforced(false);
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        // Blurred copy of the wallpaper that fills the space around a "whole picture" wallpaper
        wallpaperFill = new ImageView(this);
        wallpaperFill.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaperFill.setAlpha(0.6f);
        root.addView(wallpaperFill, new FrameLayout.LayoutParams(-1, -1));

        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(wallpaper, new FrameLayout.LayoutParams(-1, -1));

        View scrim = new View(this);
        scrim.setBackgroundColor(0x44000000);
        root.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        pager = new HomePager(this, this);
        root.addView(pager, new FrameLayout.LayoutParams(-1, -1));

        board = new FrameLayout(this);
        board.setClickable(true);
        board.setClipChildren(false);
        pager.addView(board, new FrameLayout.LayoutParams(pageW, -1, Gravity.TOP | Gravity.LEFT));

        buildPageBar();
        root.addView(pageBar, new FrameLayout.LayoutParams(-1, px(32), Gravity.BOTTOM));

        dockBar = new LinearLayout(this);
        dockBar.setOrientation(LinearLayout.HORIZONTAL);
        dockBar.setGravity(Gravity.CENTER_VERTICAL);
        dockBar.setBackground(rounded(0x88000000, 28));
        dockScroll = new HorizontalScrollView(this);
        dockScroll.setHorizontalScrollBarEnabled(false);
        dockScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        dockScroll.setFillViewport(true);
        dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER_VERTICAL);
        dockScroll.addView(dock, new FrameLayout.LayoutParams(-2, -1));
        dockBar.addView(dockScroll, new LinearLayout.LayoutParams(0, -1, 1f));
        DotsButton allApps = new DotsButton(this);
        allApps.setContentDescription("All apps");
        allApps.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openDrawer(); }
        });
        dockBar.addView(allApps, new LinearLayout.LayoutParams(px(60), px(56)));
        root.addView(dockBar, new FrameLayout.LayoutParams(-1, px(72), Gravity.BOTTOM));

        feedStore = new FeedStore(prefs);
        feed = new FeedScreen(this, feedStore, new FeedScreen.Listener() {
            @Override public void onCloseDrag(float dx) { feed.setTranslationX(dx); }
            @Override public void onCloseRelease(float dx, float vx) {
                if (dx < -pageW * 0.3f || vx < -900 * d) closeFeed(true);
                else openFeed(true);
            }
        });
        feed.setVisibility(View.GONE);
        root.addView(feed, new FrameLayout.LayoutParams(-1, -1));

        buildDrawer();
        root.addView(drawer, new FrameLayout.LayoutParams(-1, -1));

        View.OnLongClickListener menu = new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { showHomeMenu(); return true; }
        };
        board.setOnLongClickListener(menu);
        root.setLongClickable(true);
        root.setOnLongClickListener(menu);

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets ins) {
                if (Build.VERSION.SDK_INT >= 30) {
                    Insets bars = ins.getInsets(WindowInsets.Type.systemBars());
                    Insets all = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                    insetTop = bars.top;
                    insetBottom = bars.bottom;
                    imeBottom = all.bottom;
                } else {
                    insetTop = ins.getSystemWindowInsetTop();
                    insetBottom = ins.getSystemWindowInsetBottom();
                    imeBottom = insetBottom;
                }
                applyInsets();
                return ins;
            }
        });
        // If the real screen width differs from what we guessed, re-flow the pages
        root.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                final int w = r - l;
                if (w > 0 && w != pageW) ui.post(new Runnable() { @Override public void run() { setPageWidth(w); } });
            }
        });
        setContentView(root);
        applyInsets();
    }

    /** Row above the dock: page dots in the middle, + (add page) on the right. */
    private void buildPageBar() {
        pageBar = new FrameLayout(this);
        pageDots = new PageDots(this);
        pageBar.addView(pageDots, new FrameLayout.LayoutParams(-1, -1));

        TextView plus = new TextView(this);
        plus.setText("+");
        plus.setTextColor(0xFFFF8A3D);
        plus.setTextSize(20);
        plus.setGravity(Gravity.CENTER);
        plus.setIncludeFontPadding(false);
        plus.setBackground(rounded(0x88000000, 16));
        plus.setContentDescription("Add a home page");
        plus.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { addPageFromButton(); }
        });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(px(32), px(32), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        lp.rightMargin = px(20);
        pageBar.addView(plus, lp);
    }

    private void applyInsets() {
        FrameLayout.LayoutParams bp = (FrameLayout.LayoutParams) pager.getLayoutParams();
        bp.topMargin = insetTop + px(8);
        bp.bottomMargin = insetBottom + px(72 + 12 + 32 + 4);
        pager.setLayoutParams(bp);
        FrameLayout.LayoutParams pb = (FrameLayout.LayoutParams) pageBar.getLayoutParams();
        pb.bottomMargin = insetBottom + px(72 + 12 + 2);
        pageBar.setLayoutParams(pb);
        FrameLayout.LayoutParams dp = (FrameLayout.LayoutParams) dockBar.getLayoutParams();
        dp.leftMargin = px(12);
        dp.rightMargin = px(12);
        dp.bottomMargin = insetBottom + px(12);
        dockBar.setLayoutParams(dp);
        feed.setPadding(0, insetTop, 0, insetBottom);
        drawer.setPadding(0, insetTop, 0, imeBottom);
    }

    // =====================================================================================
    // Wallpaper
    // =====================================================================================

    private File wallpaperFile() { return new File(getFilesDir(), "wallpaper.jpg"); }

    /** "fit" shows the whole picture with a blurred fill around it; "fill" crops it to cover the screen. */
    private boolean wallpaperFits() { return !"fill".equals(prefs.getString("wall_mode", "fit")); }

    private void loadWallpaper() {
        Bitmap bm = null;
        File f = wallpaperFile();
        if (f.exists()) {
            try { bm = BitmapFactory.decodeFile(f.getAbsolutePath()); } catch (Throwable ignored) { }
        }
        if (bm == null) {
            try { bm = BitmapFactory.decodeResource(getResources(), R.drawable.wallpaper); } catch (Throwable ignored) { }
        }
        if (bm == null) return;
        wallpaper.setImageBitmap(bm);
        boolean fit = wallpaperFits();
        wallpaper.setScaleType(fit ? ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.CENTER_CROP);
        if (fit) {
            // A tiny copy stretched back up looks soft; Android 12+ blurs it properly on top of that.
            int sw = Math.max(1, bm.getWidth() / 12), sh = Math.max(1, bm.getHeight() / 12);
            wallpaperFill.setImageBitmap(Bitmap.createScaledBitmap(bm, sw, sh, true));
            if (Build.VERSION.SDK_INT >= 31) {
                wallpaperFill.setRenderEffect(RenderEffect.createBlurEffect(24 * d, 24 * d, Shader.TileMode.CLAMP));
            }
            wallpaperFill.setVisibility(View.VISIBLE);
        } else {
            wallpaperFill.setImageDrawable(null);
            wallpaperFill.setVisibility(View.GONE);
        }
    }

    private void wallpaperMenu() {
        final boolean fit = wallpaperFits();
        new AlertDialog.Builder(this).setTitle("Wallpaper")
                .setItems(new String[]{"Choose from my photos", "Use the Cerberus default",
                                fit ? "Fill the screen (crop the picture)" : "Show the whole picture"},
                        new android.content.DialogInterface.OnClickListener() {
                            @Override public void onClick(android.content.DialogInterface dlg, int which) {
                                if (which == 0) chooseWallpaper();
                                else if (which == 1) {
                                    wallpaperFile().delete();
                                    loadWallpaper();
                                } else {
                                    prefs.edit().putString("wall_mode", fit ? "fill" : "fit").apply();
                                    loadWallpaper();
                                }
                            }
                        }).show();
    }

    private void chooseWallpaper() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_WALLPAPER);
        } catch (Exception e) {
            toast("No photo picker found");
        }
    }

    private void saveWallpaper(final Uri uri) {
        new Thread(new Runnable() { @Override public void run() {
            boolean ok = false;
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                InputStream in = getContentResolver().openInputStream(uri);
                BitmapFactory.decodeStream(in, null, o);
                in.close();
                int s = 1;
                while (Math.max(o.outWidth, o.outHeight) / s > MAX_EDGE * 2) s *= 2;
                o.inJustDecodeBounds = false;
                o.inSampleSize = s;
                in = getContentResolver().openInputStream(uri);
                Bitmap bm = BitmapFactory.decodeStream(in, null, o);
                in.close();
                if (bm != null) {
                    int big = Math.max(bm.getWidth(), bm.getHeight());
                    if (big > MAX_EDGE) {
                        float k = MAX_EDGE / (float) big;
                        bm = Bitmap.createScaledBitmap(bm, Math.round(bm.getWidth() * k), Math.round(bm.getHeight() * k), true);
                    }
                    FileOutputStream out = new FileOutputStream(wallpaperFile());
                    bm.compress(Bitmap.CompressFormat.JPEG, 90, out);
                    out.close();
                    ok = true;
                }
            } catch (Throwable ignored) { }
            final boolean fine = ok;
            ui.post(new Runnable() { @Override public void run() {
                if (fine) { loadWallpaper(); toast("Wallpaper set"); }
                else toast("Couldn't load that picture");
            } });
        } }).start();
    }

    // =====================================================================================
    // Board: built-in blocks and hosted Android widgets
    // =====================================================================================

    /** x is in dp from the left edge of its page. */
    private WidgetFrame addFrame(String kind, int id, int page, float x, float y, float w, float h) {
        WidgetFrame f = new WidgetFrame(this, kind, id, this);
        f.page = page;
        f.pageWidthPx = pageW;
        View content;
        if ("clock".equals(kind)) {
            content = new ClockPanel(this);
        } else if ("weather".equals(kind)) {
            weatherPanel = new WeatherPanel(this, prefs);
            content = weatherPanel;
        } else {
            AppWidgetProviderInfo info = awm.getAppWidgetInfo(id);
            if (info == null) {
                discardWidgetId(id);
                return null;
            }
            try {
                AppWidgetHostView hv = host.createView(this, id, info);
                hv.updateAppWidgetSize(null, (int) w, (int) h, (int) w, (int) h);
                content = hv;
            } catch (Exception e) {
                discardWidgetId(id);
                return null;
            }
        }
        f.setContent(content);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(px(w), px(h));
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.leftMargin = page * pageW + px(x);
        lp.topMargin = px(y);
        board.addView(f, lp);
        return f;
    }

    private List<WidgetFrame> frames() {
        List<WidgetFrame> out = new ArrayList<>();
        for (int i = 0; i < board.getChildCount(); i++) {
            View v = board.getChildAt(i);
            if (v instanceof WidgetFrame) out.add((WidgetFrame) v);
        }
        return out;
    }

    private void loadLayout() {
        board.removeAllViews();
        weatherPanel = null;
        pageCount = Math.max(1, Math.min(MAX_PAGES, prefs.getInt("pages", 1)));
        current = 0;
        String s = prefs.getString("layout", null);
        if (s == null) {
            float w = dpWidth() - 32;
            addFrame("clock", -1, 0, 16, 8, w, 110);
            addFrame("weather", -1, 0, 16, 128, w, 230);
            applyBoardWidth();
            saveLayout();
            return;
        }
        try {
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                int pg = Math.max(0, Math.min(MAX_PAGES - 1, o.optInt("p", 0))); // 0.1 layouts have no "p"
                pageCount = Math.max(pageCount, pg + 1);
                addFrame(o.getString("k"), o.optInt("id", -1), pg, (float) o.getDouble("x"), (float) o.getDouble("y"),
                        (float) o.getDouble("w"), (float) o.getDouble("h"));
            }
        } catch (Exception ignored) { }
        applyBoardWidth();
        saveLayout(); // drops any widget that no longer exists
    }

    private void saveLayout() {
        try {
            JSONArray a = new JSONArray();
            for (WidgetFrame f : frames()) {
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) f.getLayoutParams();
                JSONObject o = new JSONObject();
                o.put("k", f.kind);
                o.put("id", f.widgetId);
                o.put("p", f.page);
                o.put("x", (double) ((lp.leftMargin - f.page * pageW) / d));
                o.put("y", (double) (lp.topMargin / d));
                o.put("w", (double) (lp.width / d));
                o.put("h", (double) (lp.height / d));
                a.put(o);
            }
            prefs.edit().putString("layout", a.toString()).putInt("pages", pageCount).apply();
        } catch (Exception ignored) { }
    }

    private boolean hasKind(String kind) {
        for (int i = 0; i < board.getChildCount(); i++) {
            View v = board.getChildAt(i);
            if (v instanceof WidgetFrame && ((WidgetFrame) v).kind.equals(kind)) return true;
        }
        return false;
    }

    /** Lowest edge of the blocks on the page being shown, in dp. */
    private float bottomOfBlocks() {
        float bottom = 0;
        for (WidgetFrame f : frames()) {
            if (f.page != current) continue;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) f.getLayoutParams();
            bottom = Math.max(bottom, (lp.topMargin + lp.height) / d);
        }
        return bottom;
    }

    private float nextY(float h) {
        float y = bottomOfBlocks() + 8;
        float boardH = board.getHeight() / d;
        if (boardH > 0 && y + h > boardH) y = 8;
        return y;
    }

    private void addBuiltIn(String kind) {
        float w = dpWidth() - 32;
        float h = "clock".equals(kind) ? 110 : 230;
        WidgetFrame f = addFrame(kind, -1, current, 16, nextY(h), w, h);
        saveLayout();
        if (f != null) f.startEditing();
    }

    private void exitEdit() {
        if (editingFrame != null) {
            editingFrame.setEditing(false);
            editingFrame = null;
            // Drop pages that dragging to the edge made but that ended up empty
            while (pageCount > 1 && autoPages.contains(pageCount - 1) && pageIsEmpty(pageCount - 1)) {
                autoPages.remove(pageCount - 1);
                removePage(pageCount - 1);
            }
            autoPages.clear();
            saveLayout();
        }
    }

    // WidgetFrame.Listener

    @Override public void onEditStart(WidgetFrame f) {
        if (editingFrame != null && editingFrame != f) editingFrame.setEditing(false);
        editingFrame = f;
        f.bringToFront();
    }

    @Override public void onChanged(WidgetFrame f) {
        View c = f.getContent();
        if (c instanceof AppWidgetHostView) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) f.getLayoutParams();
            int w = Math.round(lp.width / d), h = Math.round(lp.height / d);
            ((AppWidgetHostView) c).updateAppWidgetSize(null, w, h, w, h);
        }
        saveLayout();
    }

    @Override public void onRemove(WidgetFrame f) {
        if ("widget".equals(f.kind)) discardWidgetId(f.widgetId);
        if ("weather".equals(f.kind)) weatherPanel = null;
        if (f == editingFrame) editingFrame = null;
        board.removeView(f);
        saveLayout();
    }

    @Override public void onEdgeHold(WidgetFrame f, int dir) {
        int target = current + dir;
        if (target < 0) return;
        if (target >= pageCount) {
            // Only grow a new page if the page we're leaving still has something else on it
            if (pageCount >= MAX_PAGES || pageIsEmptyExcept(current, f)) return;
            pageCount++;
            autoPages.add(pageCount - 1);
            applyBoardWidth();
        }
        int shift = (target - f.page) * pageW;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) f.getLayoutParams();
        lp.leftMargin += shift;
        f.setLayoutParams(lp);
        f.page = target;
        f.shiftStart(shift);
        f.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
        goToPage(target, true, f);
    }

    // =====================================================================================
    // Home pages
    // =====================================================================================

    private boolean pageIsEmpty(int p) { return pageIsEmptyExcept(p, null); }

    private boolean pageIsEmptyExcept(int p, WidgetFrame skip) {
        for (WidgetFrame f : frames()) if (f.page == p && f != skip) return false;
        return true;
    }

    /** Sizes the wide board to hold every page and refreshes the dots. */
    private void applyBoardWidth() {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) board.getLayoutParams();
        lp.width = pageCount * pageW;
        board.setLayoutParams(lp);
        if (current >= pageCount) current = pageCount - 1;
        if (pageAnim == null || !pageAnim.isRunning()) board.setTranslationX(-current * pageW);
        pageDots.set(pageCount, current);
    }

    /** Screen width changed (or our first guess was off): keep every block where it was on its page. */
    private void setPageWidth(int w) {
        for (WidgetFrame f : frames()) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) f.getLayoutParams();
            lp.leftMargin = f.page * w + (lp.leftMargin - f.page * pageW);
            f.pageWidthPx = w;
            f.setLayoutParams(lp);
        }
        pageW = w;
        applyBoardWidth();
        rebuildDock();
    }

    /** Slides to page target. A block being dragged ("pinned") stays under the finger. */
    private void goToPage(int target, boolean animate, final WidgetFrame pinned) {
        target = Math.max(0, Math.min(pageCount - 1, target));
        current = target;
        pageDots.set(pageCount, current);
        if (pageAnim != null) pageAnim.cancel();
        final float end = -target * pageW;
        if (!animate) {
            board.setTranslationX(end);
            if (pinned != null) pinned.setTranslationX(0);
            return;
        }
        float start = board.getTranslationX();
        if (pinned != null) pinned.setTranslationX(end - start);
        pageAnim = ValueAnimator.ofFloat(start, end);
        pageAnim.setDuration(240);
        pageAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                float v = (float) a.getAnimatedValue();
                board.setTranslationX(v);
                if (pinned != null) pinned.setTranslationX(end - v);
            }
        });
        pageAnim.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator a) {
                board.setTranslationX(end);
                if (pinned != null) pinned.setTranslationX(0);
            }
        });
        pageAnim.start();
    }

    private void addPageFromButton() {
        if (drawerOpen) return;
        exitEdit();
        if (pageCount >= MAX_PAGES) {
            toast("That's the most pages (" + MAX_PAGES + ")");
            return;
        }
        pageCount++;
        applyBoardWidth();
        saveLayout();
        goToPage(pageCount - 1, true, null);
        toast("Page " + pageCount + " added. Hold empty space to add widgets.");
    }

    /** Removes page p and everything on it; later pages slide down one. */
    private void removePage(int p) {
        if (pageCount <= 1) return;
        for (WidgetFrame f : frames()) {
            if (f.page == p) {
                if ("widget".equals(f.kind)) discardWidgetId(f.widgetId);
                if ("weather".equals(f.kind)) weatherPanel = null;
                if (f == editingFrame) editingFrame = null;
                board.removeView(f);
            } else if (f.page > p) {
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) f.getLayoutParams();
                lp.leftMargin -= pageW;
                f.page--;
                f.setLayoutParams(lp);
            }
        }
        pageCount--;
        if (current > p || current >= pageCount) current = Math.max(0, current - 1);
        applyBoardWidth();
        goToPage(current, false, null);
    }

    private void confirmRemovePage() {
        final int p = current;
        int n = 0;
        for (WidgetFrame f : frames()) if (f.page == p) n++;
        if (n == 0) {
            removePage(p);
            saveLayout();
            return;
        }
        new AlertDialog.Builder(this).setTitle("Remove page " + (p + 1) + "?")
                .setMessage("This also removes the " + n + (n == 1 ? " block" : " blocks") + " on it.")
                .setPositiveButton("Remove", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) {
                        removePage(p);
                        saveLayout();
                    }
                })
                .setNegativeButton("Cancel", null).show();
    }

    // HomePager.Host

    @Override public boolean canSwipePages() {
        return !drawerOpen && !feedOpen && editingFrame == null;
    }

    @Override public void onPageDrag(float dx) {
        if (pageAnim != null) pageAnim.cancel();
        // Dragging right from the first page pulls the news feed in from the left
        if (feedDragging || (current == 0 && dx > 0)) {
            feedDragging = true;
            board.setTranslationX(0);
            if (feed.getVisibility() != View.VISIBLE) feed.setVisibility(View.VISIBLE);
            feed.setTranslationX(-pageW + Math.max(0, Math.min(pageW, dx)));
            return;
        }
        float base = -current * pageW;
        // resist past the last page
        if (current == pageCount - 1 && dx < 0) dx /= 3f;
        board.setTranslationX(base + dx);
    }

    @Override public void onPageRelease(float dx, float vx) {
        if (feedDragging) {
            feedDragging = false;
            if (dx > pageW * 0.3f || vx > 900 * d) openFeed(true);
            else closeFeed(true);
            return;
        }
        int target = current;
        if (dx < -pageW * 0.3f || vx < -900 * d) target = current + 1;
        else if (dx > pageW * 0.3f || vx > 900 * d) target = current - 1;
        goToPage(target, true, null);
    }

    // ---- news feed (left of page 1) ----

    private void openFeed(boolean animate) {
        feedOpen = true;
        feed.setVisibility(View.VISIBLE);
        feed.animate().cancel();
        if (animate) feed.animate().translationX(0).setDuration(200).start();
        else feed.setTranslationX(0);
        feed.onShown();
    }

    private void closeFeed(boolean animate) {
        feedDragging = false;
        feedOpen = false;
        feed.animate().cancel();
        if (animate && feed.getVisibility() == View.VISIBLE) {
            feed.animate().translationX(-pageW).setDuration(200).withEndAction(new Runnable() {
                @Override public void run() { if (!feedOpen) feed.setVisibility(View.GONE); }
            }).start();
        } else {
            feed.setVisibility(View.GONE);
        }
    }

    // ---- adding an Android widget ----

    private static class Prov {
        AppWidgetProviderInfo info;
        String text;
        boolean first;
    }

    private void pickWidget() {
        final PackageManager pm = getPackageManager();
        final List<Prov> list = new ArrayList<>();
        for (AppWidgetProviderInfo info : awm.getInstalledProviders()) {
            Prov p = new Prov();
            p.info = info;
            String app;
            try {
                app = pm.getApplicationLabel(pm.getApplicationInfo(info.provider.getPackageName(), 0)).toString();
            } catch (Exception e) {
                app = info.provider.getPackageName();
            }
            String wl = String.valueOf(info.loadLabel(pm));
            int cw = Math.max(1, Math.round((info.minWidth / d + 30) / 70f));
            int ch = Math.max(1, Math.round((info.minHeight / d + 30) / 70f));
            p.text = app + " - " + wl + " (" + cw + "x" + ch + ")";
            p.first = info.provider.getPackageName().toLowerCase(Locale.US).contains("symfonium");
            list.add(p);
        }
        Collections.sort(list, (a, b) -> {
            if (a.first != b.first) return a.first ? -1 : 1;
            return a.text.compareToIgnoreCase(b.text);
        });
        if (list.isEmpty()) {
            toast("No widgets found on this phone");
            return;
        }
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) names[i] = list.get(i).text;
        new AlertDialog.Builder(this).setTitle("Add widget")
                .setItems(names, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) {
                        startBind(list.get(which).info);
                    }
                }).show();
    }

    private void setPending(int id) { prefs.edit().putInt("pending_widget", id).apply(); }

    private int takePending() {
        int id = prefs.getInt("pending_widget", -1);
        prefs.edit().remove("pending_widget").apply();
        return id;
    }

    private void discardWidgetId(int id) {
        if (id < 0) return;
        try { host.deleteAppWidgetId(id); } catch (Exception ignored) { }
    }

    private void startBind(AppWidgetProviderInfo info) {
        int id = host.allocateAppWidgetId();
        boolean ok = false;
        try { ok = awm.bindAppWidgetIdIfAllowed(id, info.provider); } catch (Exception ignored) { }
        if (ok) {
            afterBind(id);
            return;
        }
        // Android asks the person once to allow this launcher to show widgets
        setPending(id);
        Intent i = new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider);
        try {
            startActivityForResult(i, REQ_BIND);
        } catch (Exception e) {
            takePending();
            discardWidgetId(id);
            toast("Couldn't add that widget");
        }
    }

    private void afterBind(int id) {
        AppWidgetProviderInfo info = awm.getAppWidgetInfo(id);
        if (info != null && info.configure != null) {
            setPending(id);
            try {
                host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null);
                return;
            } catch (Exception e) {
                takePending();
            }
        }
        placeWidget(id);
    }

    private void placeWidget(int id) {
        AppWidgetProviderInfo info = awm.getAppWidgetInfo(id);
        if (info == null) {
            discardWidgetId(id);
            toast("Couldn't add that widget");
            return;
        }
        float bw = dpWidth();
        float minW = info.minWidth / d;
        float w = minW >= 180 ? bw - 32 : Math.max(minW, 100);
        float h = Math.max(info.minHeight / d, 90);
        float x = Math.max(8, (bw - w) / 2);
        WidgetFrame f = addFrame("widget", id, current, x, nextY(h), w, h);
        saveLayout();
        if (f != null) {
            f.startEditing();
            toast("Drag to move, corner handle to resize");
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_BIND) {
            int id = takePending();
            if (res == RESULT_OK && id >= 0) afterBind(id);
            else discardWidgetId(id);
        } else if (req == REQ_CONFIG) {
            int id = takePending();
            if (res == RESULT_OK && id >= 0) placeWidget(id);
            else discardWidgetId(id);
        } else if (req == REQ_WALLPAPER) {
            if (res == RESULT_OK && data != null && data.getData() != null) saveWallpaper(data.getData());
        }
    }

    // =====================================================================================
    // Home menu (long-press empty space)
    // =====================================================================================

    private void showHomeMenu() {
        if (drawerOpen) return;
        final List<String> names = new ArrayList<>();
        final List<Runnable> acts = new ArrayList<>();
        names.add("Add widget");
        acts.add(new Runnable() { @Override public void run() { pickWidget(); } });
        if (!hasKind("clock")) {
            names.add("Add clock");
            acts.add(new Runnable() { @Override public void run() { addBuiltIn("clock"); } });
        }
        if (!hasKind("weather")) {
            names.add("Add weather");
            acts.add(new Runnable() { @Override public void run() { addBuiltIn("weather"); } });
        }
        if (pageCount < MAX_PAGES) {
            names.add("Add page");
            acts.add(new Runnable() { @Override public void run() { addPageFromButton(); } });
        }
        if (pageCount > 1) {
            names.add("Remove this page");
            acts.add(new Runnable() { @Override public void run() { confirmRemovePage(); } });
        }
        names.add("News feed");
        acts.add(new Runnable() { @Override public void run() { goToPage(0, true, null); openFeed(true); } });
        names.add("Manage news feeds");
        acts.add(new Runnable() { @Override public void run() { feed.manageFeeds(); } });
        names.add("Wallpaper");
        acts.add(new Runnable() { @Override public void run() { wallpaperMenu(); } });
        names.add("Set my city");
        acts.add(new Runnable() { @Override public void run() { askCity(); } });
        final boolean f = "F".equals(prefs.getString("unit", "F"));
        names.add(f ? "Temperature: switch to Celsius" : "Temperature: switch to Fahrenheit");
        acts.add(new Runnable() { @Override public void run() {
            prefs.edit().putString("unit", f ? "C" : "F").apply();
            if (weatherPanel != null) weatherPanel.refresh(true);
        } });
        if (!isDefaultHome()) {
            names.add("Set as home app");
            acts.add(new Runnable() { @Override public void run() { requestHome(); } });
        }
        names.add("About");
        acts.add(new Runnable() { @Override public void run() { showAbout(); } });
        new AlertDialog.Builder(this).setTitle("Cerberus Launcher")
                .setItems(names.toArray(new String[0]), new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) { acts.get(which).run(); }
                }).show();
    }

    private void askCity() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("City name, e.g. Leeds or Dallas");
        input.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Set my city").setView(input)
                .setPositiveButton("Search", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) {
                        WeatherPanel.lookupCity(MainActivity.this, prefs, input.getText().toString().trim(), new Runnable() {
                            @Override public void run() { if (weatherPanel != null) weatherPanel.refresh(true); }
                        });
                    }
                })
                .setNegativeButton("Cancel", null).show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this).setTitle("Cerberus Launcher " + VERSION)
                .setMessage("Onknight Studios\n\nHold a widget to move or resize it; hold it against the screen edge to move it to "
                        + "another page. Swipe sideways for pages, tap + to add one. From the first page, swipe right to read your news. Swipe up for all apps. "
                        + "The dock scrolls sideways once you have more apps than fit. Hold an app for options. Hold empty space for this menu.\n\nThis is a beta, so please report anything odd.")
                .setPositiveButton("OK", null).show();
    }

    private void showWelcome() {
        prefs.edit().putBoolean("welcomed", true).apply();
        new AlertDialog.Builder(this).setTitle("Welcome to Cerberus Launcher")
                .setMessage("Beta " + VERSION + ". Make it your home app, pick a wallpaper, then hold empty space to add widgets.")
                .setPositiveButton("Set as home app", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) { requestHome(); }
                })
                .setNeutralButton("Choose wallpaper", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) { chooseWallpaper(); }
                })
                .setNegativeButton("Later", null).show();
    }

    private boolean isDefaultHome() {
        Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(h, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null && getPackageName().equals(ri.activityInfo.packageName);
    }

    private void requestHome() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = getSystemService(RoleManager.class);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_ROLE);
                    return;
                }
            }
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { }
        }
    }

    // =====================================================================================
    // Apps, dock and drawer
    // =====================================================================================

    private void refreshApps() {
        new Thread(new Runnable() { @Override public void run() {
            PackageManager pm = getPackageManager();
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris = pm.queryIntentActivities(i, 0);
            final List<AppInfo> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (ResolveInfo ri : ris) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                AppInfo a = new AppInfo();
                a.pkg = pkg;
                a.cls = ri.activityInfo.name;
                a.label = String.valueOf(ri.loadLabel(pm));
                a.lower = a.label.toLowerCase(Locale.getDefault());
                a.icon = ri.loadIcon(pm);
                out.add(a);
            }
            Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
            ui.post(new Runnable() { @Override public void run() {
                apps = out;
                defaultDockIfNeeded();
                pruneDock();
                rebuildDock();
                filter(search.getText().toString());
            } });
        } }).start();
    }

    private AppInfo find(String pkg) {
        for (AppInfo a : apps) if (a.pkg.equals(pkg)) return a;
        return null;
    }

    private void loadDockPrefs() {
        dockPkgs.clear();
        String s = prefs.getString("dock", "");
        if (!TextUtils.isEmpty(s)) {
            for (String p : s.split(",")) if (!p.isEmpty()) dockPkgs.add(p);
        }
    }

    private void saveDock() {
        prefs.edit().putString("dock", TextUtils.join(",", dockPkgs)).apply();
    }

    private void addDefault(List<String> out, Intent i) {
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        if (ri == null || ri.activityInfo == null) return;
        String pkg = ri.activityInfo.packageName;
        if (find(pkg) != null && !out.contains(pkg)) out.add(pkg);
    }

    private void defaultDockIfNeeded() {
        if (prefs.contains("dock") || apps.isEmpty()) return;
        List<String> out = new ArrayList<>();
        addDefault(out, new Intent(Intent.ACTION_DIAL));
        addDefault(out, new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING));
        addDefault(out, new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.example.com")));
        addDefault(out, new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
        for (AppInfo a : apps) {
            if (a.lower.contains("symfonium")) {
                if (!out.contains(a.pkg)) out.add(a.pkg);
                break;
            }
        }
        dockPkgs.clear();
        for (String p : out) if (dockPkgs.size() < DOCK_MAX) dockPkgs.add(p);
        saveDock();
    }

    private void pruneDock() {
        if (apps.isEmpty()) return;
        boolean changed = false;
        for (int i = dockPkgs.size() - 1; i >= 0; i--) {
            if (find(dockPkgs.get(i)) == null) {
                dockPkgs.remove(i);
                changed = true;
            }
        }
        if (changed) saveDock();
    }

    private void rebuildDock() {
        dock.removeAllViews();
        // Few apps: spread them across the bar. Many apps: fixed size, and the bar scrolls sideways.
        int barW = pageW - px(24) - px(60);
        int count = 0;
        for (String pkg : dockPkgs) if (find(pkg) != null) count++;
        int cell = Math.max(px(56), count == 0 ? px(56) : barW / count);
        for (String pkg : dockPkgs) {
            final AppInfo a = find(pkg);
            if (a == null) continue;
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(a.icon);
            iv.setContentDescription(a.label);
            iv.setPadding(px(4), px(4), px(4), px(4));
            iv.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { launch(a); }
            });
            iv.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) { showAppMenu(a); return true; }
            });
            dock.addView(iv, new LinearLayout.LayoutParams(cell, px(56)));
        }
        dockScroll.scrollTo(0, 0);
    }

    private void launch(AppInfo a) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(new ComponentName(a.pkg, a.cls))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
            closeDrawer(false);
        } catch (Exception e) {
            toast("Can't open " + a.label);
        }
    }

    private void showAppMenu(final AppInfo a) {
        final boolean inDock = dockPkgs.contains(a.pkg);
        String[] items = {inDock ? "Remove from dock" : "Add to dock", "App info", "Uninstall"};
        new AlertDialog.Builder(this).setTitle(a.label)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dlg, int which) {
                        try {
                            if (which == 0) {
                                if (inDock) dockPkgs.remove(a.pkg);
                                else if (dockPkgs.size() >= DOCK_MAX) { toast("Dock is full (" + DOCK_MAX + " apps)"); return; }
                                else dockPkgs.add(a.pkg);
                                saveDock();
                                rebuildDock();
                            } else if (which == 1) {
                                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)));
                            } else {
                                startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
                            }
                        } catch (Exception e) {
                            toast("Couldn't do that");
                        }
                    }
                }).show();
    }

    private void buildDrawer() {
        drawer = new FrameLayout(this);
        drawer.setBackgroundColor(0xF2090A0F);
        drawer.setClickable(true);
        drawer.setFocusableInTouchMode(true);
        drawer.setVisibility(View.GONE);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        search = new EditText(this);
        search.setHint("Search apps");
        search.setHintTextColor(0x99FFFFFF);
        search.setTextColor(Color.WHITE);
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_GO);
        search.setBackground(rounded(0x33FFFFFF, 24));
        search.setPadding(px(18), px(12), px(18), px(12));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(px(16), px(12), px(16), px(8));
        col.addView(search, sp);

        grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setVerticalSpacing(px(6));
        grid.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        grid.setPadding(px(8), 0, px(8), 0);
        grid.setClipToPadding(false);
        adapter = new AppAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) { launch(shown.get(pos)); }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                showAppMenu(shown.get(pos));
                return true;
            }
        });
        col.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1f));
        drawer.addView(col, new FrameLayout.LayoutParams(-1, -1));

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { filter(s.toString()); }
        });
        search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent ev) {
                if (!shown.isEmpty()) launch(shown.get(0));
                return true;
            }
        });
    }

    private void filter(String q) {
        shown.clear();
        q = q.trim().toLowerCase(Locale.getDefault());
        if (q.isEmpty()) {
            shown.addAll(apps);
        } else {
            for (AppInfo a : apps) if (a.lower.startsWith(q)) shown.add(a);
            for (AppInfo a : apps) if (!a.lower.startsWith(q) && a.lower.contains(q)) shown.add(a);
        }
        adapter.notifyDataSetChanged();
    }

    private void openDrawer() {
        if (drawerOpen) return;
        exitEdit();
        drawerOpen = true;
        search.setText("");
        filter("");
        grid.setSelection(0);
        drawer.setVisibility(View.VISIBLE);
        drawer.setTranslationY(root.getHeight());
        drawer.animate().translationY(0).setDuration(220).start();
        drawer.requestFocus();
    }

    private void closeDrawer(boolean animate) {
        if (!drawerOpen) return;
        drawerOpen = false;
        hideKeyboard();
        search.clearFocus();
        if (animate) {
            drawer.animate().translationY(root.getHeight()).setDuration(200).withEndAction(new Runnable() {
                @Override public void run() { if (!drawerOpen) drawer.setVisibility(View.GONE); }
            }).start();
        } else {
            drawer.animate().cancel();
            drawer.setVisibility(View.GONE);
        }
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
    }

    private class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override public View getView(int pos, View cv, ViewGroup parent) {
            LinearLayout cell;
            if (cv == null) {
                cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setPadding(px(4), px(8), px(4), px(4));
                cell.setLayoutParams(new AbsListView.LayoutParams(-1, px(96)));
                ImageView iv = new ImageView(MainActivity.this);
                cell.addView(iv, new LinearLayout.LayoutParams(px(52), px(52)));
                TextView tv = new TextView(MainActivity.this);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(12);
                tv.setSingleLine(true);
                tv.setEllipsize(TextUtils.TruncateAt.END);
                tv.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
                tp.topMargin = px(6);
                cell.addView(tv, tp);
            } else {
                cell = (LinearLayout) cv;
            }
            AppInfo a = shown.get(pos);
            ((ImageView) cell.getChildAt(0)).setImageDrawable(a.icon);
            ((TextView) cell.getChildAt(1)).setText(a.label);
            return cell;
        }
    }

    /** Little dots above the dock showing which home page you're on. */
    private static class PageDots extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int count = 1, cur = 0;

        PageDots(Context c) { super(c); }

        void set(int count, int cur) {
            this.count = count;
            this.cur = cur;
            invalidate();
        }

        @Override protected void onDraw(Canvas cv) {
            if (count <= 1) return;
            float dd = getResources().getDisplayMetrics().density;
            float gap = 14 * dd, r = 3.5f * dd;
            float x0 = getWidth() / 2f - (count - 1) * gap / 2f, cy = getHeight() / 2f;
            for (int i = 0; i < count; i++) {
                p.setColor(i == cur ? 0xFFFF8A3D : 0x88FFFFFF);
                cv.drawCircle(x0 + i * gap, cy, i == cur ? r * 1.3f : r, p);
            }
        }
    }

    /** The "all apps" button at the end of the dock: a 3x3 grid of dots. */
    private static class DotsButton extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        DotsButton(Context c) {
            super(c);
            p.setColor(0xFFFF8A3D);
        }

        @Override protected void onDraw(Canvas cv) {
            float s = Math.min(getWidth(), getHeight());
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float step = s * 0.2f, r = s * 0.05f;
            for (int i = -1; i <= 1; i++)
                for (int j = -1; j <= 1; j++)
                    cv.drawCircle(cx + i * step, cy + j * step, r, p);
        }
    }
}
