package studio.onknight.cerberus;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextClock;

/** Built-in clock block. Text scales with the size of the block. */
class ClockPanel extends LinearLayout {
    private final TextClock time, date;
    private final float d;

    ClockPanel(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        int pad = (int) (8 * d);
        setPadding(pad, 0, pad, 0);

        time = new TextClock(c);
        time.setFormat12Hour("h:mm a");
        time.setFormat24Hour("HH:mm");
        time.setTextColor(Color.WHITE);
        time.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        time.setSingleLine(true);
        time.setShadowLayer(10, 0, 2, 0xAA000000);

        date = new TextClock(c);
        date.setFormat12Hour("EEEE, MMM d");
        date.setFormat24Hour("EEEE, MMM d");
        date.setTextColor(0xFFFFA24A);
        date.setSingleLine(true);
        date.setShadowLayer(8, 0, 2, 0xAA000000);

        addView(time, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        addView(date, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        time.setTextSize(TypedValue.COMPLEX_UNIT_PX, 48 * d);
        date.setTextSize(TypedValue.COMPLEX_UNIT_PX, 16 * d);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        float ts = Math.min(h * 0.52f, (w - 16 * d) / 4.6f);
        ts = Math.max(ts, 18 * d);
        time.setTextSize(TypedValue.COMPLEX_UNIT_PX, ts);
        date.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.max(ts * 0.32f, 11 * d));
    }
}
