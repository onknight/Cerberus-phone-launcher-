package studio.onknight.cerberus;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Weather icons drawn in code, no image files. */
class WeatherIcon extends View {
    private int code = -1;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();

    WeatherIcon(Context c) { super(c); }

    void setCode(int c) { code = c; invalidate(); }

    static int kind(int c) {
        if (c == 0) return 0;
        if (c <= 2) return 1;
        if (c == 3) return 2;
        if (c == 45 || c == 48) return 3;
        if ((c >= 51 && c <= 67) || (c >= 80 && c <= 82)) return 4;
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) return 5;
        if (c >= 95) return 6;
        return 2;
    }

    @Override protected void onDraw(Canvas cv) {
        if (code < 0) return;
        float s = Math.min(getWidth(), getHeight());
        cv.save();
        cv.translate((getWidth() - s) / 2f, (getHeight() - s) / 2f);
        switch (kind(code)) {
            case 0:
                sun(cv, s * 0.5f, s * 0.5f, s * 0.22f);
                break;
            case 1:
                sun(cv, s * 0.36f, s * 0.34f, s * 0.15f);
                cloud(cv, s * 0.56f, s * 0.58f, s * 0.78f, 0xFFE8EEF7);
                break;
            case 2:
                cloud(cv, s * 0.5f, s * 0.5f, s * 0.84f, 0xFFC9D3E0);
                break;
            case 3:
                cloud(cv, s * 0.5f, s * 0.38f, s * 0.8f, 0xFFB5C2D3);
                stroke(0xFF9FB0C6, s * 0.06f);
                cv.drawLine(s * 0.25f, s * 0.68f, s * 0.75f, s * 0.68f, p);
                cv.drawLine(s * 0.32f, s * 0.82f, s * 0.68f, s * 0.82f, p);
                break;
            case 4:
                cloud(cv, s * 0.5f, s * 0.36f, s * 0.8f, 0xFFB5C2D3);
                stroke(0xFF4FB3FF, s * 0.06f);
                for (float x : new float[]{0.32f, 0.5f, 0.68f})
                    cv.drawLine(x * s, 0.6f * s, (x - 0.06f) * s, 0.82f * s, p);
                break;
            case 5:
                cloud(cv, s * 0.5f, s * 0.36f, s * 0.8f, 0xFFD5DEEA);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.WHITE);
                cv.drawCircle(s * 0.32f, s * 0.68f, s * 0.045f, p);
                cv.drawCircle(s * 0.5f, s * 0.82f, s * 0.045f, p);
                cv.drawCircle(s * 0.68f, s * 0.68f, s * 0.045f, p);
                break;
            default:
                cloud(cv, s * 0.5f, s * 0.36f, s * 0.8f, 0xFF8E9BB0);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFFFD43B);
                path.reset();
                path.moveTo(s * 0.54f, s * 0.58f);
                path.lineTo(s * 0.40f, s * 0.80f);
                path.lineTo(s * 0.50f, s * 0.80f);
                path.lineTo(s * 0.44f, s * 0.96f);
                path.lineTo(s * 0.64f, s * 0.70f);
                path.lineTo(s * 0.53f, s * 0.70f);
                path.lineTo(s * 0.60f, s * 0.58f);
                path.close();
                cv.drawPath(path, p);
                break;
        }
        cv.restore();
    }

    private void stroke(int color, float width) {
        p.setStyle(Paint.Style.STROKE);
        p.setColor(color);
        p.setStrokeWidth(width);
        p.setStrokeCap(Paint.Cap.ROUND);
    }

    private void sun(Canvas cv, float cx, float cy, float r) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFC83D);
        cv.drawCircle(cx, cy, r, p);
        stroke(0xFFFFC83D, r * 0.28f);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI / 4 * i;
            float c = (float) Math.cos(a), sn = (float) Math.sin(a);
            cv.drawLine(cx + c * r * 1.45f, cy + sn * r * 1.45f, cx + c * r * 1.9f, cy + sn * r * 1.9f, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void cloud(Canvas cv, float cx, float cy, float w, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        float r = w * 0.2f;
        cv.drawCircle(cx - w * 0.22f, cy, r, p);
        cv.drawCircle(cx + w * 0.02f, cy - r * 0.55f, r * 1.25f, p);
        cv.drawCircle(cx + w * 0.26f, cy + r * 0.05f, r * 0.9f, p);
        rect.set(cx - w * 0.42f, cy, cx + w * 0.44f, cy + r);
        cv.drawRoundRect(rect, r * 0.5f, r * 0.5f, p);
    }
}
